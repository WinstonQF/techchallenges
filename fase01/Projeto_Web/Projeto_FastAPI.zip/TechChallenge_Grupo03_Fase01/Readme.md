# API com FastAPI

1) Verifique se você tem a linguagem python em sua máquina:

<code>python --version</code>
ou
<code>python3 --version</code>

2) Crie um ambiente virtual para instalar somente as bibliotecas do projeto:

<code>python3 -m venv ./venv</code>

3) Instale as bibliotecas que vamos precisar

<code>pip install "fastapi[standard]"</code>
<code>pip install scikit-learn==1.3.2</code>
<code>pip install xgboost</code>


4) Quando estiver pronto para subir a API, use o comando <code>fastapi dev api.py</code>

---







