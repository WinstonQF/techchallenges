from typing import Union
from pydantic import BaseModel
from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
import pickle

app = FastAPI()
templates = Jinja2Templates(directory="templates")

class Client(BaseModel):
    age: int
    sex: str
    bmi: float
    children: int
    smoker: str
    region: str

def convert_sex(sex):
    mapeamento = {
        'female': 0, 
        'male': 1
    }
    return mapeamento.get(sex)

def convert_smoker(smoker):
    mapeamento = {
        'no': 0, 
        'yes': 1
    }
    return mapeamento.get(smoker)

def convert_region(region):
    mapeamento = {
        'northeast': 0, 
        'northwest': 1, 
        'southeast': 2, 
        'southwest': 3
    }
    return mapeamento.get(region)

@app.get("/", response_class=HTMLResponse)
def read_root(request: Request):
    return templates.TemplateResponse("form.html", {"request": request})

@app.post("/register", response_class=HTMLResponse)
async def new_order(request: Request, age: int = Form(...), sex: str = Form(...), bmi: float = Form(...), children: int = Form(...), smoker: str = Form(...), region: str = Form(...)):
    sex = convert_sex(sex)
    region = convert_region(region)
    smoker = convert_smoker(smoker)
    
    filename = "model_v1.pkl"
    model = pickle.load(open(filename, 'rb'))
    
    
    """
    Parâmetros do método predict para o XBoost Regressor
    ----------------------------------------------------
    X :
        Dados de entrada (estrutura do treino) para prever
    output_margin :
        Se deve ou não emitir o valor de margem bruto não transformado.
    validate_features :
        Quando isso for Verdadeiro, valide se os feature_names do Booster e dos dados são
        idênticos. Caso contrário, presume-se que os feature_names são os mesmos.
    base_margin :
        Viés global para cada instância. Veja :doc:`/tutorials/intercept` para detalhes.
    
    Returns
    -------
    Previsão

    """
    # Certifique-se de que os dados de entrada estão no formato correto (uma lista de listas)
    value = model.predict([[age, sex, bmi, children, smoker, region, True, True, None]])
    
    # Retorne a resposta como um dicionário JSON serializável
    return templates.TemplateResponse("form.html", {"request": request, "value": value[0]})